package main;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CrudTendenciasApplicationTests {

	@Test
	void contextLoads() {
	}

}
