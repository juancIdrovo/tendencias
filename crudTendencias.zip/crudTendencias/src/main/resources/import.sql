INSERT INTO `usuarios` (`id`, `nombre`, `clave`, `mail`, `estado`) VALUES ('1','Juan', 'jsio', 'juancidrovo@gmail.com', 'false');

