package dao;

import org.springframework.data.repository.CrudRepository;

import model.Usuario;

public interface IusuarioDao extends CrudRepository<Usuario, Long>{

}
