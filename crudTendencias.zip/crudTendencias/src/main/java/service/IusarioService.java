package service;

import java.util.List;

import model.Usuario;

public interface IusarioService {
	
	public List <Usuario> findAll();
	
	public Usuario save (Usuario usuario);
	
	public Usuario findById (Long id);
	
	public void delete (Long id);

}
